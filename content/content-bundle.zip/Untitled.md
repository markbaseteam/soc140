
# Week 6 Discussion
## Attendance
[tinyurl.com/140attendance](http://tinyurl.com/140attendance)
Today’s code: 6

#### Notes

-   Exercise 3 due Feb 24 5 pm (next Friday) - come to office hours if you’d like to view the videos again
	%% testing testing  %%
-   Fill out Prof. Stivers’s mid-quarter survey on Canvas

#### Compare and contrast the opioid and antibiotic epidemics

* How do their impacts compare/contrast?
* How do their origins and contributing factors compare/contrast?
* How does social interaction in each context compare/contrast?

#### Moldanado & Moldanado 2017

-   What sorts of factors place individuals at risk of developing chronic disease? What are modifiable and non-modifiable risk factors?
	%% 
	
	
	
	%%
-   What are the different stages of chronic disease?
    
    susceptibility to disease, pre-symptomatic or pre-clinical disease, symptomatic, disability
    
-   What has contributed to the increasing prevalence of chronic disease over time? How has this impacted the doctor-patient relationship?


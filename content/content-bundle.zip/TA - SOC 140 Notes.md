### Students who have missed 3 sections
- Isabel Foerster
- Kecheng Jiang
- Yue Que
- Brooke Savage
- Long Xiang
